vegan for D-RUG
========================================================
author: Tim Bowles
date: December 9, 2014

Introductions
========================================================
I'm a sixth year student in the GGE. I study plant-soil-microbe interactions, nitrogen cycling, and soil ecology in agroecosystems.

Who are you and what do your data frames look like? (personal question, I know)

My goal today is to help you develop skills and confidence to use vegan for analyzing your data.

Overview of what we will cover
========================================================
* unconstrained ordination
  + principal components analysis (PCA)
  + non-metric multi-dimensional scaling (NMDS)
    + dissimilarity indices
* relating community data to environmental variables
<small>(Or more generally, how does one matrix relate to another?)</small>
  + fitting environmental vectors over ordination
  + constrained ordination
     + redundancy analysis (RDA)
     + partial RDA and variance partitioning
  * dissimilarities and environment
  + permutational tests

Resources
========================================================
* [vegan tutorial](http://cc.oulu.fi/~jarioksa/opetus/metodi/vegantutor.pdf)
* [Customizing vegan's ordination plots](http://www.fromthebottomoftheheap.net/2012/04/11/customising-vegans-ordination-plots/)
* [Numerical Ecology with R](http://link.springer.com/book/10.1007%2F978-1-4419-7976-6)
* some additional papers are listed throughout
* `help()`
* `args()`

Unconstrained Ordination
========================================================

Soil biogeochemical data
========================================================

```r
soil <- read.table("soil.txt", header=T)
soil$field <- as.factor(rep(1:13, each = 6))
str(soil)
```

```
'data.frame':	78 obs. of  16 variables:
 $ soil.C   : num  7.1 6.8 6.7 6.7 6.9 5.9 9.9 9.2 9.9 9.9 ...
 $ soil.N   : num  0.9 0.9 0.8 0.8 0.8 0.7 1.2 1.1 1.2 1.2 ...
 $ soilCtoN : num  7.89 7.56 8.38 8.38 8.62 ...
 $ clay     : num  16.2 13.2 16.6 12.6 12.2 ...
 $ silt     : num  53.5 45.1 57.6 42.2 41.7 ...
 $ sand     : num  30.3 41.8 25.8 45.2 46.1 ...
 $ pH       : num  7.02 6.82 6.88 6.41 6.57 6.35 6.75 6.6 6.5 7.07 ...
 $ ln.olsenP: num  2.98 3.17 3.01 2.94 3.24 ...
 $ mbc      : num  67.5 68.8 55.2 88.7 70 ...
 $ mbn      : num  6.19 6.25 7.28 9.79 8.28 5.25 6.14 3.65 4.12 1.51 ...
 $ doc      : num  18.6 22.9 31.8 21.6 23.5 ...
 $ don      : num  2.25 2.51 5.18 2.37 2.6 2.66 5.49 4.83 5.26 5.06 ...
 $ ln.nh4   : num  0.247 0.207 0.215 0.255 0.215 ...
 $ ln.no3   : num  0.07696 0.14842 0.00995 0.02956 0 ...
 $ gwc      : num  0.169 0.148 0.148 0.145 0.151 0.141 0.169 0.153 0.145 0.145 ...
 $ field    : Factor w/ 13 levels "1","2","3","4",..: 1 1 1 1 1 1 2 2 2 2 ...
```

PCA with vegan
========================================================

```r
library(vegan)
soil.pca <- rda(soil[,1:15], scale=T)
#only continuous variables
#scale variables that are on different measurement scales (i.e. this is a correlation matrix, not a variance-covariance matrix)
#NA's are :(

library(dplyr) #data frame manipulation by Hadley
soil.pca <- rda(select(soil, soil.C:gwc), scale=T) #same as above
```

Display results of PCA
========================================================

```r
summary(soil.pca, display=NULL)
```

```

Call:
rda(X = select(soil, soil.C:gwc), scale = T) 

Partitioning of correlations:
              Inertia Proportion
Total              15          1
Unconstrained      15          1

Eigenvalues, and their contribution to the correlations 

Importance of components:
                        PC1   PC2   PC3   PC4    PC5    PC6    PC7    PC8
Eigenvalue            4.790 3.000 2.207 1.689 1.4139 0.7396 0.3044 0.2584
Proportion Explained  0.319 0.200 0.147 0.113 0.0943 0.0493 0.0203 0.0172
Cumulative Proportion 0.319 0.519 0.666 0.779 0.8733 0.9226 0.9429 0.9601
                         PC9   PC10    PC11    PC12   PC13    PC14
Eigenvalue            0.2433 0.1666 0.08836 0.05992 0.0390 0.00101
Proportion Explained  0.0162 0.0111 0.00589 0.00399 0.0026 0.00007
Cumulative Proportion 0.9763 0.9874 0.99334 0.99733 0.9999 1.00000
                          PC15
Eigenvalue            4.23e-06
Proportion Explained  0.00e+00
Cumulative Proportion 1.00e+00

Scaling 2 for species and site scores
* Species are scaled proportional to eigenvalues
* Sites are unscaled: weighted dispersion equal on all dimensions
* General scaling constant of scores:  
```

Display loading scores
========================================================

```r
scores(soil.pca, choices = 1:2, display="species", scaling=0)
```

```
                PC1      PC2
soil.C     0.444071 -0.07705
soil.N     0.439559 -0.04654
soilCtoN   0.334296 -0.13012
clay      -0.071757  0.38983
silt       0.205067  0.42089
sand      -0.131117 -0.44997
pH        -0.030648 -0.22047
ln.olsenP -0.005889 -0.08879
mbc        0.316092  0.24193
mbn        0.175813  0.19165
doc        0.387523 -0.20313
don        0.362337 -0.19779
ln.nh4    -0.073544  0.31386
ln.no3     0.081208  0.30990
gwc        0.090431  0.12922
attr(,"const")
[1] 5.83
```

Plot results of PCA - basic
========================================================

```r
plot(soil.pca)
```

![plot of chunk unnamed-chunk-5](vegan D-RUG-figure/unnamed-chunk-5.png) 

***
* `vegan` has built-in methods for dealing with its objects 
* but the default output for plots is not ready for publication
* how to customize?

Plot results of PCA - nicer
========================================================

```r
scl = 3
plot(soil.pca, type = "n", scaling = scl)
text(soil.pca, display = "species", cex = 1, col = '#000000', scaling = scl)
```

![plot of chunk unnamed-chunk-6](vegan D-RUG-figure/unnamed-chunk-6.png) 

***

* build up plots step by step
* make sure scaling is the same if multiple plots are used

Graphical display of factors:
========================================================
+ `ordihull`, `ordispider`, and `ordiellipse`


```r
plot(soil.pca, type = "n", scaling = scl)
points(soil.pca, display = "sites", scaling = scl)
ordiellipse(soil.pca, soil$field, kind = "se",
            conf = 0.95, lwd=1, draw = "polygon",
            col="skyblue", border = "blue", label = T, cex = 1, scaling = scl)
```

![plot of chunk unnamed-chunk-7](vegan D-RUG-figure/unnamed-chunk-7.png) 

Graphical display of factors:
========================================================

```r
plot(soil.pca, type = "n", scaling = scl)
ordispider(soil.pca, soil$field, col="red", label=T, scaling=scl)
ordihull(soil.pca, soil$field, co="red", lty=2, scaling=scl)
```

![plot of chunk unnamed-chunk-8](vegan D-RUG-figure/unnamed-chunk-8.png) 

Plot results of PCA
========================================================

```r
library(extrafont) #allows use of other fonts in plots and output graphics
loadfonts()

pdf("soilPCAscaling3.pdf", family = 'Arial', width = 12, height = 6) #export PDF of the following plots with specified preferences

layout(matrix(1:2, ncol = 2)) #make two plots next to each other
###
scl = 3
plot(soil.pca, type = "n", scaling = scl)
text(soil.pca, display = "species", cex = 1, col = '#000000', scaling = scl)

plot(soil.pca, type = "n", scaling = scl)
points(soil.pca, display = "sites", scaling = scl)
ellipse <- ordiellipse(soil.pca, soil$field, kind = "se", 
                       conf = 0.95, lwd=1, draw = "polygon", 
                       col="skyblue", border = "blue", label = T, cex = 1,
                       scaling = scl)
###
dev.off() #close PDF device
```

Extract site and variable scores for maximum plotting flexibility
========================================================

```r
plot.scrs <- as.data.frame(scores(soil.pca, display = c("sites"), scaling=scl, choices = c(1,2)))
str(plot.scrs)
```

```
'data.frame':	78 obs. of  2 variables:
 $ PC1: num  -0.952 -1.048 -0.811 -0.95 -0.96 ...
 $ PC2: num  -0.257 -0.605 -0.241 -0.573 -0.731 ...
```

```r
var.scrs <- as.data.frame(scores(soil.pca, display = c("species"), scaling=scl, choices = c(1,2)))
str(var.scrs)
```

```
'data.frame':	15 obs. of  2 variables:
 $ PC1: num  1.946 1.926 1.465 -0.314 0.899 ...
 $ PC2: num  -0.3 -0.181 -0.507 1.52 1.641 ...
```
* These could then be passed onto other plotting packages like `ggplot2` for maximum flexibility, but as far as I know neat built-in function like `ordiellipse` won't work.

NMDS - species data
========================================================


```r
data(varespec)
str(varespec)
```

```
'data.frame':	24 obs. of  44 variables:
 $ Cal.vul: num  0.55 0.67 0.1 0 0 ...
 $ Emp.nig: num  11.13 0.17 1.55 15.13 12.68 ...
 $ Led.pal: num  0 0 0 2.42 0 0 1.55 0 0.35 0.07 ...
 $ Vac.myr: num  0 0.35 0 5.92 0 ...
 $ Vac.vit: num  17.8 12.1 13.5 16 23.7 ...
 $ Pin.syl: num  0.07 0.12 0.25 0 0.03 0.12 0.1 0.1 0.05 0.12 ...
 $ Des.fle: num  0 0 0 3.7 0 0.02 0.78 0 0.4 0 ...
 $ Bet.pub: num  0 0 0 0 0 0 0.02 0 0 0 ...
 $ Vac.uli: num  1.6 0 0 1.12 0 0 2 0 0.2 0 ...
 $ Dip.mon: num  2.07 0 0 0 0 0 0 0 0 0.07 ...
 $ Dic.sp : num  0 0.33 23.43 0 0 ...
 $ Dic.fus: num  1.62 10.92 0 3.63 3.42 ...
 $ Dic.pol: num  0 0.02 1.68 0 0.02 0.02 0 0.23 0.2 0 ...
 $ Hyl.spl: num  0 0 0 6.7 0 0 0 0 9.97 0 ...
 $ Ple.sch: num  4.67 37.75 32.92 58.07 19.42 ...
 $ Pol.pil: num  0.02 0.02 0 0 0.02 0.02 0 0 0 0 ...
 $ Pol.jun: num  0.13 0.23 0.23 0 2.12 1.58 0 0.02 0.08 0.02 ...
 $ Pol.com: num  0 0 0 0.13 0 0.18 0 0 0 0 ...
 $ Poh.nut: num  0.13 0.03 0.32 0.02 0.17 0.07 0.1 0.13 0.07 0.03 ...
 $ Pti.cil: num  0.12 0.02 0.03 0.08 1.8 0.27 0.03 0.1 0.03 0.25 ...
 $ Bar.lyc: num  0 0 0 0.08 0.02 0.02 0 0 0 0.07 ...
 $ Cla.arb: num  21.73 12.05 3.58 1.42 9.08 ...
 $ Cla.ran: num  21.47 8.13 5.52 7.63 9.22 ...
 $ Cla.ste: num  3.5 0.18 0.07 2.55 0.05 ...
 $ Cla.unc: num  0.3 2.65 8.93 0.15 0.73 0.25 2.38 0.82 0.05 0.95 ...
 $ Cla.coc: num  0.18 0.13 0 0 0.08 0.1 0.17 0.15 0.02 0.17 ...
 $ Cla.cor: num  0.23 0.18 0.2 0.38 1.42 0.25 0.13 0.05 0.03 0.05 ...
 $ Cla.gra: num  0.25 0.23 0.48 0.12 0.5 0.18 0.18 0.22 0.07 0.23 ...
 $ Cla.fim: num  0.25 0.25 0 0.1 0.17 0.1 0.2 0.22 0.1 0.18 ...
 $ Cla.cri: num  0.23 1.23 0.07 0.03 1.78 0.12 0.2 0.17 0.02 0.57 ...
 $ Cla.chl: num  0 0 0.1 0 0.05 0.05 0.02 0 0 0.02 ...
 $ Cla.bot: num  0 0 0.02 0.02 0.05 0.02 0 0 0.02 0.07 ...
 $ Cla.ama: num  0.08 0 0 0 0 0 0 0 0 0 ...
 $ Cla.sp : num  0.02 0 0 0.02 0 0 0.02 0.02 0 0.07 ...
 $ Cet.eri: num  0.02 0.15 0.78 0 0 0 0.02 0.18 0 0.18 ...
 $ Cet.isl: num  0 0.03 0.12 0 0 0 0 0.08 0.02 0.02 ...
 $ Cet.niv: num  0.12 0 0 0 0.02 0.02 0 0 0 0 ...
 $ Nep.arc: num  0.02 0 0 0 0 0 0 0 0 0 ...
 $ Ste.sp : num  0.62 0.85 0.03 0 1.58 0.28 0 0.03 0.02 0.03 ...
 $ Pel.aph: num  0.02 0 0 0.07 0.33 0 0 0 0 0.02 ...
 $ Ich.eri: num  0 0 0 0 0 0 0 0.07 0 0 ...
 $ Cla.cer: num  0 0 0 0 0 0 0 0 0 0 ...
 $ Cla.def: num  0.25 1 0.33 0.15 1.97 0.37 0.15 0.67 0.08 0.47 ...
 $ Cla.phy: num  0 0 0 0 0 0 0 0 0 0 ...
```

Running NMDS
========================================================


```r
varespec.nmds.bray <- metaMDS(varespec, distance="bray", trace=FALSE, trymax=100)
varespec.nmds.bray
```

```

Call:
metaMDS(comm = varespec, distance = "bray", trymax = 100, trace = FALSE) 

global Multidimensional Scaling using monoMDS

Data:     wisconsin(sqrt(varespec)) 
Distance: bray 

Dimensions: 2 
Stress:     0.1826 
Stress type 1, weak ties
Two convergent solutions found after 6 tries
Scaling: centring, PC rotation, halfchange scaling 
Species: expanded scores based on 'wisconsin(sqrt(varespec))' 
```


metaMDS - a wrapper function
========================================================
* Wraps several recommended procedures into one command:
 + takes raw data and performs 'Wisconsin double standardization'
 + calculates specified dissimilarity matrix
 + runs vegan function `monoMDS` many times with random starts, stopping when it finds two similar configurations with minimum stress
 + rotates solution so largest variation of site score is on first axis
 + other details in [vegan tutor](http://cc.oulu.fi/~jarioksa/opetus/metodi/vegantutor.pdf)
 
plotting NMDS
========================================================

```r
plot(varespec.nmds.bray, type="t")
```

![plot of chunk unnamed-chunk-13](vegan D-RUG-figure/unnamed-chunk-13.png) 

***

* With many variables/sites, ordination plots can quickly become overwhelming or unreadable
* some built-in function to help include:
 + `make.cepnames`
 + `orditorp`
 + `ordilabel`

evaluating NMDS mapping
========================================================

```r
stressplot(varespec.nmds.bray)
```

![plot of chunk unnamed-chunk-14](vegan D-RUG-figure/unnamed-chunk-14.png) 

***


```r
gof <- goodness(varespec.nmds.bray)
plot(varespec.nmds.bray, type="t", main="goodness of fit")
points(varespec.nmds.bray, display="sites", cex=gof*100)
```

![plot of chunk unnamed-chunk-15](vegan D-RUG-figure/unnamed-chunk-15.png) 

Comparing ordinations
========================================================
* Comparing different ordinations can be difficult because of slightly
different orientation and scaling. Procrustes rotation using `procrustes` allows comparison

```r
varespec.nmds.eu <- metaMDS(varespec, distance="eu", trace=FALSE, trymax=100) # use euclidean distance - probably not a good choice for most community analyses
pro <- procrustes(varespec.nmds.bray, varespec.nmds.eu)
```

Comparing ordinations
========================================================

```r
plot(pro, cex=1.5)
```

![plot of chunk unnamed-chunk-17](vegan D-RUG-figure/unnamed-chunk-17.png) 

Comparing ordinations
========================================================

```r
plot(pro, kind=2)
```

![plot of chunk unnamed-chunk-18](vegan D-RUG-figure/unnamed-chunk-18.png) 

dissimilarity indices
========================================================
* `metaMDS` automatically standardizes and then calculates specified dissimilarity index
* `vegdist` will take a matrix of sites (rows) and variables/species (columns) and calculate specied dissimilarity index, outputs class `dist`

```r
varespec.kul <- vegdist(varespec, method="kulczynski")
str(varespec.kul)
```

```
Class 'dist'  atomic [1:276] 0.531 0.668 0.549 0.375 0.508 ...
  ..- attr(*, "Size")= int 24
  ..- attr(*, "Labels")= chr [1:24] "18" "15" "24" "27" ...
  ..- attr(*, "Diag")= logi FALSE
  ..- attr(*, "Upper")= logi FALSE
  ..- attr(*, "method")= chr "kulczynski"
  ..- attr(*, "call")= language vegdist(x = varespec, method = "kulczynski")
```

For more information on association matrices in general, see chapter 3 of [Numerical Ecology with R](http://link.springer.com/book/10.1007%2F978-1-4419-7976-6)

Relating community data to environmental variables
========================================================

Overlaying environmental vectors onto ordination
========================================================
* environmental data, paired with `varespec` data

```r
data(varechem)
str(varechem)
```

```
'data.frame':	24 obs. of  14 variables:
 $ N       : num  19.8 13.4 20.2 20.6 23.8 22.8 26.6 24.2 29.8 28.1 ...
 $ P       : num  42.1 39.1 67.7 60.8 54.5 40.9 36.7 31 73.5 40.5 ...
 $ K       : num  140 167 207 234 181 ...
 $ Ca      : num  519 357 973 834 777 ...
 $ Mg      : num  90 70.7 209.1 127.2 125.8 ...
 $ S       : num  32.3 35.2 58.1 40.7 39.5 40.8 33.8 27.1 42.5 60.2 ...
 $ Al      : num  39 88.1 138 15.4 24.2 ...
 $ Fe      : num  40.9 39 35.4 4.4 3 ...
 $ Mn      : num  58.1 52.4 32.1 132 50.1 ...
 $ Zn      : num  4.5 5.4 16.8 10.7 6.6 9.1 7.4 5.2 9.3 9.1 ...
 $ Mo      : num  0.3 0.3 0.8 0.2 0.3 0.4 0.3 0.3 0.3 0.5 ...
 $ Baresoil: num  43.9 23.6 21.2 18.7 46 40.5 23 29.8 17.6 29.9 ...
 $ Humdepth: num  2.2 2.2 2 2.9 3 3.8 2.8 2 3 2.2 ...
 $ pH      : num  2.7 2.8 3 2.8 2.7 2.7 2.8 2.8 2.8 2.8 ...
```

Overlaying vectors with envfit
========================================================

```r
fit <- envfit(varespec.nmds.bray, varechem, permu=999)
fit
```

```

***VECTORS

          NMDS1  NMDS2   r2 Pr(>r)    
N        -0.057 -0.998 0.25  0.039 *  
P         0.620  0.785 0.19  0.115    
K         0.766  0.642 0.18  0.123    
Ca        0.685  0.728 0.41  0.003 ** 
Mg        0.633  0.775 0.43  0.005 ** 
S         0.191  0.982 0.18  0.121    
Al       -0.872  0.490 0.53  0.003 ** 
Fe       -0.936  0.352 0.45  0.002 ** 
Mn        0.799 -0.602 0.52  0.001 ***
Zn        0.618  0.787 0.19  0.115    
Mo       -0.903  0.430 0.06  0.500    
Baresoil  0.925 -0.380 0.25  0.050 *  
Humdepth  0.933 -0.360 0.52  0.001 ***
pH       -0.648  0.762 0.23  0.050 *  
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
P values based on 999 permutations.
```

***

<small>
* first two columns are direction cosines of the vectors, and `r2` gives the squared correlation coefficient
* when plotted, vectors should be scaled by square root of `r2`. `plot` does this automatically (see next slide)
* significances (`Pr>r`) are based on  random permutations of the data: if if you often get as good or better R2 with randomly permuted data, your values are insignificant.
</small>

Plotting envfit output
========================================================
* The arrow points to the direction of most rapid change in the the
environmental variable. Often this is called the direction of the
gradient.
*  The length of the arrow is proportional to the correlation between
ordination and environmental variable. Often this is called the
strength of the gradient.

***


```r
plot(varespec.nmds.bray, display="sites")
plot(fit, p.max=0.05) #only display variables that are significant
```

![plot of chunk unnamed-chunk-22](vegan D-RUG-figure/unnamed-chunk-22.png) 

Other options
========================================================
* `envfit` also works with factors
* vector fitting implies a linear relationship between ordination and environment
* function `ordisurf` fits surfaces of environmental variables to ordinations based on generalized additive models in function `gam` of package mgcv.
* see vegan tutor or help files for more details.

Constrained ordination - RDA
========================================================
* Look only at variation in response (e.g. species) matrix that can be explained by explanatory (e.g. environmental) variables, i.e. constraints
* RDA combines multivariate regression (multiple y's and multiple x's) and principal components analysis.
* 'constrains' ordination of species X sample matrix by a multiple linear regression of an environmental matrix
* related to PCA (Euclidean distances)
* For community composition data as response variables, a few of alternatives exist:
 + distance-based RDA (see Numerical Ecology with R)
 + transformation-based RDA [(Legendre and Gallagher 2001)](http://link.springer.com/article/10.1007%2Fs004420100716)
 + constrained correspondence analysis (CCA)
 
Data - soil enzyme activities
========================================================

```r
enz <- read.table("enzymes.txt", header=T)
str(enz)
```

```
'data.frame':	78 obs. of  9 variables:
 $ b.glucosidase          : num  67.2 92.1 72.9 77.5 78.9 ...
 $ a.galactosidase        : num  4.73 4.74 4.97 8.42 8.57 4.11 6.69 6.7 6.68 7.32 ...
 $ b.glucosaminidase      : num  18.1 31.8 26.4 32.1 27.9 ...
 $ alk.monophosphoesterase: num  91.8 100.3 73.2 72.4 81.1 ...
 $ phosphodiesterase      : num  56.1 95.5 86.2 59.4 81 ...
 $ arylsulfatase          : num  6.73 10.02 7.99 8.95 10.58 ...
 $ l.asparaginase         : num  11.6 9.14 10.99 15.88 10.99 ...
 $ urease                 : num  29.3 26.9 26.9 30.5 36 ...
 $ aspartase              : num  64.7 66 71.2 62.7 73.3 ...
```

* Paired with soil variables we used in PCA
* measured across 13 organic fields in Yolo Co.
* How do soil properties drive soil enzyme activities? 

Selecting explanatory variables
========================================================

```r
enz.rda <- rda(enz ~ ., 
               data = select(soil, soil.C:gwc), 
               scale = T)
stepping <- ordiR2step(rda(enz ~ 1, data = soil, scale = T),
                     scope = formula(enz.rda), direction = "forward",
                     pstep = 1000, trace = F)
anova(stepping)
```

```
Permutation test for rda under reduced model

Model: rda(formula = enz ~ mbc + soil.N + ln.no3 + gwc + soil.C + mbn + ln.nh4 + soilCtoN + ln.olsenP + doc + don, data = soil, scale = T)
         Df  Var    F N.Perm Pr(>F)   
Model    11 6.29 13.9    199  0.005 **
Residual 66 2.71                      
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
```
* Keep in mind that selection procedures should be used with caution
* See [Blanchet et al 2008](http://www.esajournals.org/doi/abs/10.1890/07-0986.1)

Running RDA with selected explanatory variables
========================================================

```r
enz.rda.step <- rda(enz ~ mbc + soil.N + ln.no3 + gwc + soil.C + mbn + ln.nh4 + soilCtoN + ln.olsenP + doc + don, data = soil, scale = T) #fit reduced model
RsquareAdj(enz.rda.step)$adj.r.squared
```

```
[1] 0.6488
```

```r
summary(enz.rda.step, display = NULL)
```

```

Call:
rda(formula = enz ~ mbc + soil.N + ln.no3 + gwc + soil.C + mbn +      ln.nh4 + soilCtoN + ln.olsenP + doc + don, data = soil, scale = T) 

Partitioning of correlations:
              Inertia Proportion
Total            9.00      1.000
Constrained      6.29      0.699
Unconstrained    2.71      0.301

Eigenvalues, and their contribution to the correlations 

Importance of components:
                       RDA1  RDA2   RDA3   RDA4   RDA5    RDA6    RDA7
Eigenvalue            3.760 1.264 0.5589 0.3638 0.2116 0.08364 0.02640
Proportion Explained  0.418 0.140 0.0621 0.0404 0.0235 0.00929 0.00293
Cumulative Proportion 0.418 0.558 0.6203 0.6607 0.6843 0.69356 0.69649
                         RDA8    RDA9    PC1    PC2    PC3    PC4    PC5
Eigenvalue            0.01325 0.00892 0.8589 0.6519 0.3279 0.2110 0.1864
Proportion Explained  0.00147 0.00099 0.0954 0.0724 0.0364 0.0234 0.0207
Cumulative Proportion 0.69796 0.69895 0.7944 0.8668 0.9033 0.9267 0.9474
                         PC6    PC7    PC8     PC9
Eigenvalue            0.1646 0.1484 0.0959 0.06441
Proportion Explained  0.0183 0.0165 0.0107 0.00716
Cumulative Proportion 0.9657 0.9822 0.9928 1.00000

Accumulated constrained eigenvalues
Importance of components:
                       RDA1  RDA2   RDA3   RDA4   RDA5   RDA6   RDA7
Eigenvalue            3.760 1.264 0.5589 0.3638 0.2116 0.0836 0.0264
Proportion Explained  0.598 0.201 0.0888 0.0578 0.0336 0.0133 0.0042
Cumulative Proportion 0.598 0.799 0.8875 0.9454 0.9790 0.9923 0.9965
                         RDA8    RDA9
Eigenvalue            0.01325 0.00892
Proportion Explained  0.00211 0.00142
Cumulative Proportion 0.99858 1.00000

Scaling 2 for species and site scores
* Species are scaled proportional to eigenvalues
* Sites are unscaled: weighted dispersion equal on all dimensions
* General scaling constant of scores:  
```

Evaluating model
========================================================

```r
vif.cca(enz.rda.step)
```

```
      mbc    soil.N    ln.no3       gwc    soil.C       mbn    ln.nh4 
    2.826   375.759     3.249     1.361   570.188     3.141     2.210 
 soilCtoN ln.olsenP       doc       don 
   41.651     3.172    13.940    11.820 
```

```r
anova.cca(enz.rda.step, step = 1000) #global test of the RDA result
```

```
Permutation test for rda under reduced model

Model: rda(formula = enz ~ mbc + soil.N + ln.no3 + gwc + soil.C + mbn + ln.nh4 + soilCtoN + ln.olsenP + doc + don, data = soil, scale = T)
         Df  Var    F N.Perm Pr(>F)    
Model    11 6.29 13.9    999  0.001 ***
Residual 66 2.71                       
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
```

Evaluating model
========================================================

```r
anova.cca(enz.rda.step, step = 1000, by = "axis") #tests of all canonical axes
```

```
Model: rda(formula = enz ~ mbc + soil.N + ln.no3 + gwc + soil.C + mbn +      ln.nh4 + soilCtoN + ln.olsenP + doc + don, data = soil, scale = T)
         Df  Var     F N.Perm Pr(>F)    
RDA1      1 3.76 94.37    999  0.001 ***
RDA2      1 1.26 31.73    999  0.001 ***
RDA3      1 0.56 14.03    999  0.001 ***
RDA4      1 0.36  9.13    999  0.001 ***
RDA5      1 0.21  5.31    999  0.001 ***
RDA6      1 0.08  2.10   4999  0.059 .  
RDA7      1 0.03  0.66    999  0.668    
RDA8      1 0.01  0.33    999  0.938    
RDA9      1 0.01  0.22    999  0.983    
Residual 68 2.71                        
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
```

Plotting model results - response and explanatory variables
========================================================







```
Error in pdf("enzymeRDA.pdf", width = 6, height = 6) : 
  cannot open file 'enzymeRDA.pdf'
```
